package com.example.infs3634CatAppHomework3;

public class CatDetail {

    private Cat[] breeds;
    private String id;

    private String url;

    public Cat[] getBreeds() {
        return breeds;
    }

    public void setBreeds(Cat[] breeds) {
        this.breeds = breeds;
    }

    public String getId() {
        return id;
    }

    public void setId(String CatId) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

}
